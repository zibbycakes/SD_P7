package testPackage;

public class P {
	public void foo() {
		// method foo of class P
	}
}
