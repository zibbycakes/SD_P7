package testPackage;

public class C {
	public void m(A a) {}
}
