package testPackage;

public class B  {
	public void calculateAnswer(int p1, A p2, B p3) {
		// method calculateAnswer of class B
	}
}
