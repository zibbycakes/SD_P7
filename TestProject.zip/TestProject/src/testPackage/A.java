package testPackage;

public class A extends P {
	public int i = 0;
	
	public void foo() {
		// method foo of class A
	}
	
	public void getFinalData() {
		// method getFinalData of class A
		runFast();
	}
	
	public void runFast() {
		// method runFast of class A
		i++;
	}
}
