package myPackage;

import java.util.ArrayList;

import p.actions.*;

public class MyClass {
	public void myMethod() {
		///////////////////////////////////////////////////////////////////////
		//
		//	Write your script here
		// Create a Visitor Pattern
		RPackage pkg = RProject.getPackage("RefactoringCrawlerWithVisitor", "edu.uiuc.detectRefactorings.detection");
		RClassOrInterface vis = pkg.getClass("Visitor");
		ArrayList<RMethod> visits = vis.getAllMethods();
		for(RMethod v : visits)
		{
			RParameter del = v.getParameter(0);
			v.move(del);
		}
		RClassOrInterface fd = pkg.getClass("FieldDetection");
		String[] comp = {"visit", "edu.uiuc.detectRefactorings.detection.Visitor"};
		RMethod newVisit = fd.getMethod(comp);
		ArrayList<RMethod> newVisits = newVisit.getRelatives();
		for(RMethod nv : newVisits)
		{
			nv.replace("accept");
		}
		String[] comp2 = {"accept", "edu.uiuc.detectRefactorings.detection.Visitor"};
		RMethod accept = fd.getMethod(comp2);
		ArrayList<RMethod> accepts = accept.getRelatives();
		for(RMethod acc : accepts)
		{
			RParameter visParam = acc.getParameter(0);
			acc.removeParameter(visParam);
		}
		String[] comp3 = {"accept"};
		accept = fd.getMethod(comp3);
		accepts = accept.getRelatives();
		for(RMethod acc : accepts)
		{
			acc.rename("isRename");
		}
		vis.delete();
		//
		///////////////////////////////////////////////////////////////////////
	}
}
